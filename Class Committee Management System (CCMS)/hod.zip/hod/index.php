<!DOCTYPE html>
<html lang="en">
<style>
    .a
    {
        text-decoration: none;
        color: #5a5c69 !important;
    }
    </style>
<head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>HOD portal</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
<?php session_start();?>
        <!-- Sidebar -->
        <?php include 'sidebar.php';?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Search -->
              <?php
    include"./header.php";
?>

                    <!-- Topbar Navbar -->
                    <?php include 'topnav.php'; ?>
                    <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!--/. Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
                    </div>

                    <!-- Content Row -->
                    <div class="row">
<?php
                     ?>
                        <!-- Card 1 -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <a href=scheduled_meeting.php>
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Next Meeting</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php 
                                                
                                                 $meeting="select * from meeting where  end_datetime >= CURRENT_TIMESTAMP";
     
                                               $meeting_run=mysqli_query($connection,$meeting);
                                        while($rows=mysqli_fetch_assoc($meeting_run)){
                                            
                                           
                                       
                                            echo"<td>";
                                            ?>
                                            <a href='scheduled_meeting.php?g=<?php echo $rows['group_id'];?>' class="a"><?php echo $rows['title'];?></a>
                                            <?php echo"</td>";
                                            
                                            }
                                            ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-calendar fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                    </div></a>
                            </div>
                        </div>

<!-- Meeting count -->
                        
                        <?php
                        $meeting_r=mysqli_query($connection,"select count(*) from meeting where group_id && end_datetime >= CURRENT_TIMESTAMP");
                        $count=mysqli_fetch_assoc($meeting_r);?>
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                           <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Pending Meeting</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $count['count(*)'];?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-desktop fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        
                        
                                    <?php $batchs=mysqli_query($connection,"select count(*) from batch");
                                                $batchcount=mysqli_fetch_assoc($batchs);
                    ?>
                       <!-- Pending Requests Card Example -->
                       <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                           <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Batch</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $batchcount['count(*)'];?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-desktop fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        
                        
                   
                    <?php $groups=mysqli_query($connection,"select count(*) from group_details");
                                                $groupcount=mysqli_fetch_assoc($groups);
                    ?>
                    
                     <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                           <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Group</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $groupcount['count(*)'];?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-users fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        
                        
                 
                                       
                    <?php $faculty=mysqli_query($connection,"select count(*) from faculty");
                                                $faccount=mysqli_fetch_assoc($faculty);
                    ?>
                    
                     <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                           <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Faculty</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $faccount['count(*)'];?></div>
                                        </div>
                                        <div class="col-auto">
                                           <i class="fa fa-user fa-2x text-gray-300"></i>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                                                
                    <?php $course=mysqli_query($connection,"select count(*) from course");
                                                $coursecount=mysqli_fetch_assoc($course);
                    ?>
                     <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                           <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                course</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $coursecount['count(*)'];?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-book fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        
                        
                    </div>
                    </div>
                </nav>
                
                </div>     
                    
                    <!-- 
                                        
                                        
                                        
                                        <div class="row">
                                             Reminder Card Example
                                            <div class="col-xl-12 col-md-6 mb-4">
                                                <div class="card border-left-info shadow h-100 py-2">
                                                    <div class="card-body">
                                                        <div class="row no-gutters align-items-center">
                                                            <div class="col mr-2">
                                                                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Reminder
                                                                </div>
                                                                <div class="row no-gutters align-items-center">
                                                                    <div class="col-auto">
                                                                        <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                                                                            <ul>You need to attend this meeting.its very urgent</ul><ul>Check the graph</ul></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-auto">
                                                                <i class="fas fa-bell fa-2x text-gray-300"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        Content Row
                    
                                       
                    
                    tht thing ends here
                                        <div class="row" id="classcharts">
                    
                                       
                    
                                            Pie Chart
                                            <div class="col-xl-4 col-lg-5">
                                                <div class="card shadow mb-4">
                                                    Card Header
                                                    <div
                                                        class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                                        <h6 class="m-0 font-weight-bold text-primary">C Programming</h6>
                                                        
                                                    </div>
                                                    Card Body
                                                    <div class="card-body">
                                                        <div class="chart-pie pt-4 pb-2">
                                                            <div id="piechart" style="width: auto"></div>
                                                        </div>
                                                        
                                                    </div>
                                                </div>                        
                                            </div>
                                         add more chart here
                                         
                                         
                                         
                                          -->
                     
                    </div>


                </div>
                <!-- /.container-fluid -->

            </div>
          