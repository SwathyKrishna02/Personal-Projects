<?php

include "./header.php";
include "./footer.php";

?>
<style>
.btn[name="add"]
    {
        background-color: #1e60c9;
    }
.btn[name="view"]
    {
        background-color: #1e60c9;
    }
.btn[name="cancel"]
    {
        background-color: #1e60c9;
    }
        .btn[name="update"] {
background-color: #1e60c9;
}
     #select{
 width:460px; 
        height: 40px;
}

</style>
<?php session_start();?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>   CC Chair</title>
    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.css" rel="stylesheet">
    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
</head>
<body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Sidebar -->
        <?php include 'sidebar.php';?>
        <!-- End of Sidebar -->
        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <!-- Main Content -->
            <div id="content">
                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                   <?php include 'topnav.php';
                  ?>
                </nav>
                 <div class="container-fluid">
                <!-- End of Topbar -->
  <h2 align="center">  CC Chair</h2>
  <form method="POST" class="form-inline container mt-4 mb-4">
    <div class="row">
     <div class="col-sm">
      <input class="form-control border-end-0 border rounded-pill" name="search" type="text" placeholder="Search by Group Id , Batch Name " aria-label="Search" style="width:800px" id="example-search-input">
     </div>
     <div class="col-sm">
       <button class="btn btn-outline-secondary bg-white border-bottom-0 border rounded-pill ms-n5" name="submit" value="submit" type="submit">
        <i class="fa fa-search"></i>
       </button>
       <button type="button" align="center" name="add" class="btn btn-info"  data-bs-toggle="modal" data-bs-target="#myModal">ADD</button>
     </div>
   </div>
 </form>
  <!--  display group -->
  
   <form action="" method="post">
  <div class="card-body">
                            <div class="table-responsive">
                            
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        

       <tr class="tr"align="center">
       <th>Fac Image</th>
       <th align="center"> Fac Name</th>
       <th align="center"> Group</th>
       <th align="center"> DOJ</th>
       <th align="center"> DOL</th>  
       <th align="center"> UPDATE</th>
       <th align="center"> DELETE</th>
       
                                        </tr>
                                    </thead>
                                    <tbody>
        <?php
          
      if(isset($_POST['submit']))
        {
            $keyword=$_POST['search'];
            $keywords=explode(' ',$keyword);
            $query="select * from cc_chair ";
            foreach($keywords as $k)
            {
                $query.="chair_id like '%$k%' or fac_id like '%$k%' or group like '%$k%' and ";
            }
            $batch = substr_replace($query, "", -4);
           
        }
      else
       {     
        $chair="SELECT * FROM cc_chair where dol='0000-00-00'";
        $chair_run=mysqli_query($connection,$chair);
        while($row=mysqli_fetch_assoc($chair_run))
              {      
                  $chair_id=$row['chair_id'];
                  $fac_id=$row['fac_id'];
                  $group_id=$row['group_id'];
                  $doj=$row['doj'];
                  $dol=$row['dol'];
            
              $group="SELECT name FROM group_details where group_id='$group_id'";
              $group_run=mysqli_query($connection,$group);
              while($rows=mysqli_fetch_assoc($group_run))
                {      
                  $group=$rows['name'];
                }
              $fac="SELECT fac_name FROM faculty where fac_id='$fac_id'";
             $fac_run=mysqli_query($connection,$fac);
             while($row=mysqli_fetch_assoc($fac_run))
              {      
                  $fac_name=$row['fac_name']; 
                  ?>
                  <tr> 
                    <tr> 
        <td>
       <img style="width:50px;border-radius:50%;" src="
                                           <?php 
                                            
                                             $path='../images/fac_prof/'.$fac_id.'.png';
                                             
                                             if(file_exists($path)){
                                            echo $path;
                                            }
                                             else echo "../images/fac_prof/default.png";
                                            ?>
                                                        
                                                        "> 
                                                        </td>
                  <td align="center"><?php echo  $fac_name; ?> </td>
                  <td align="center"><?php echo   $group; ?> </td>
                  <td align="center"><?php echo   $doj; ?> </td>
                  <td align="center"><?php echo   $dol; ?> </td>
                  <td align="center"> <a href="add_chair.php?update=<?php echo $chair_id;?>"style="text-decoration:none; color: white"> <i class="fa fa-edit  " style="font-size:24px;color: #1e60c9;"></i> </a></td>
                   <td align="center">  <a href="add_chair.php?delete=<?php echo $chair_id;?>" onclick="return confirm('Are you sure you want to delete this item')" style="text-decoration:none; color: white;">  <i class="fas fa-trash-alt"  style="font-size:24px;color: #bb2c2c;"></i> </a></td>
                    </tr>     
       <?php 
             }
        }
    }
         // Delete Group
          
        if(isset($_GET['delete']))
           {
            $del=$_GET['delete'];
            $dol=date("Y/m/d");
        $query_update="UPDATE cc_chair SET dol='$dol' WHERE chair_id = '$del'";
        $result_update = mysqli_query($connection,$query_update); 
        if(!$result_update)
        {
            echo mysqli_error($connection);
        }
      else
      {
         ?>
            <script> location.replace("add_chair.php"); </script>
          <?php  
          }
        }
  
             ?>
                   
          <!--  Add group -->   
    <div class="container mt-5">
        
        <div class="modal" id="myModal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header butt">
                        <h5 class="modal-title">CC Chair Add</h5>
                        <button type="button" required class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <form action="" method="post">
                           
                           
                             <div class="mb-3">
                                <label class="form-label required">Faculty Id</label>
                           <select name="facs" id="select"> 
                                <option>--select--</option>
                                 
                           
                               
           
            <?php
                        
                               
                                    $id="Select fac_id,fac_name from faculty ";
                                    $query_run=mysqli_query($connection,$id);
             while($rows=mysqli_fetch_assoc($query_run))
             {
                 $fac=$rows['fac_id'];
                 $name=$rows['fac_name'];
                 echo"<option value='$fac'>".$fac." ".$name."</option>";
             }
                               
                                 
    ?>   
                               
 </select> 
                 </div>
                         
                             <div class="mb-3">
                                <label class="form-label required">Group Name</label>
                          <select name="groups" id="select">
                                <option>--select--</option>
           
            <?php 
                               
                                    $id="Select group_id,name from group_details";
                                    $query_run=mysqli_query($connection,$id);
             while($rows=mysqli_fetch_assoc($query_run))
             {
                 $group=$rows['group_id'];
                 $group_name=$rows['name'];
                 echo"<option value='$group'>".$group_name."</option>";
             }
                               
    ?>   
                               
  </select>
                            </div>        <div class="mb-3">
                                <label class="form-label required">Date Of Joining</label>
                                 <input type="text" name="dojs" class="form-control" value="<?php echo date("Y/m/d");?>">
                 </div>
                         
                           
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="add" class="btn btn-info" >Submit</button>
                        <button type="submit"  name="cancel" class="btn btn-info" >Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    
<?php  
        if(isset($_POST['add']))
        {
            if(!empty($_POST['fac'])&&!empty($_POST['group']))
        {
             
              
              $fac=$_POST['facs']; 
              $group=$_POST['groups']; 
              $doj=$_POST['dojs'];
 
        $groupd="Select fac_id from cc_chair where fac_id='$fac' and dol= '0000-00-00' ";
    
        $group_run=mysqli_query($connection,$groupd);
        while($row=mysqli_fetch_assoc($group_run))
              {      
                  $f=$row['fac_id'];
        }
                
        $groupd2="Select group_id from cc_chair where group_id='$group' and dol= '0000-00-00' ";
         $group_run2=mysqli_query($connection,$groupd2);
        while($row=mysqli_fetch_assoc($group_run2))
              {      
                  $g=$row['group_id'];
        }
        
            if(isset($f))
            {
                
                echo "<script>alert('faculty already added to cc- chair of another Group');</script>";
            }
        
            
            else if(isset($g))
                 echo "<script>alert('group already have a cc-chair');</script>";

             else
             {
        
             $insert="INSERT INTO cc_chair(fac_id,group_id,doj) VALUES('$fac','$group','$doj')";
            
            $insert_db=mysqli_query($connection,$insert);
             
        
             
       
    if($insert_db)
    {
        
        echo "<script>alert('successfully Added');</script>";
      ?>
        <script> location.replace("add_chair.php"); </script>
        <?php
    }
            else
            {
                echo mysqli_error($connection);
            }}}
        }
        
        
          ?>
            <!--  Update group -->
       <?php if(isset($_GET['update']))
           {
       
  echo '
  <script>
    $(document).ready(function() {
      $("#mysModal").modal("show");
    });
  </script>
  ';
    }
                                        
 
    ?>
      <div class="container mt-5">
        
        <div class="modal" id="mysModal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header butt">
                        <h5 class="modal-title">CC Chair Add</h5>
                        <button type="button" required class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                       <?php$update=$_GET['update'];
                            $facupdate="select * from cc_chair where id= '$update '";
      
        $grouprun=mysqli_query($connection,$facupdate);
        while($rows=mysqli_fetch_assoc($grouprun))
              {  
                          $ids=$rows['fac_id'];
                          $group=$rows['group_id'];
                   
                           ?>
                           
                             <div class="mb-3">
                                <label class="form-label required">Faculty Id</label>
                           <select name="fac" id="select"> 
                                
                                 
                           
                               
           
            <?php
                        
                               
                                    $id="Select fac_id,fac_name from faculty ";
                                    $query_run=mysqli_query($connection,$id);
             while($rows=mysqli_fetch_assoc($query_run))
             {
                 $fac=$rows['fac_id'];
                 $name=$rows['fac_name'];
                 echo"<option value='$fac'>".$fac." ".$name."</option>";
             }
                               
                                 
    ?>   
                               
 </select> 
                 </div>
                         
                             <div class="mb-3">
                                <label class="form-label required">Group Name</label>
                          <select name="group" id="select">
                                
           
            <?php 
                               
                                    $id="Select group_id,name from group_details";
                                    $query_run=mysqli_query($connection,$id);
             while($rows=mysqli_fetch_assoc($query_run))
             {
                 $group=$rows['group_id'];
                 $group_name=$rows['name'];
                 echo"<option value='$group'>".$group_name."</option>";
             }
                               
    ?>   
                               
  </select>
                            </div>        <div class="mb-3">
                                <label class="form-label required">Date Of Joining</label>
                                 <input type="text" name="doj" class="form-control" value="<?php echo date("Y/m/d");?>">
                 </div>
                         
                           
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="add" class="btn btn-info" >Submit</button>
                        <button type="submit"  name="cancel" class="btn btn-info" >Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    
    <?php

    if(isset($_POST['update']))
    {
              
              $fac=$_POST['fac']; 
              $group=$_POST['group']; 
              $doj=$_POST['doj']; 
        
              $dol=$_POST['dol']; 
      

        $query_update="UPDATE cc_chair SET fac_id='$fac', group_id='$group', doj='$doj', dol='$dol' WHERE chair_id = '$update'";
        $result_update = mysqli_query($connection,$query_update); 
        if(!$result_update)
        {
            echo mysqli_error($connection);
        }
            ?>
   <script>location.replace("add_chair.php"); </script>
    <?php
          
        
    }


          
        
    ?>
   
   
       
        
        
        
        
        
       
    </table>          
    
<br><br>
     <div align="center">
    &emsp;
    
      
       
    </div> </form>
         
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>



    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>

