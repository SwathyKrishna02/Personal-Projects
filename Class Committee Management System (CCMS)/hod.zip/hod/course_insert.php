<style>
.btn[name="add"]
    {
        background-color: #1e60c9;
        color:white;
    }
.btn[name="view"]
    {
        background-color: #1e60c9;
    }
.btn[name="cancel"]
    {
        background-color: #1e60c9;
    }
        .btn[name="update"] {
background-color: #1e60c9;
}
    #select{
 width:460px; 
        height: 40px;
}
</style><?php

include "./header.php";
include "./footer.php";

// css
?>
<?php session_start();?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Batch</title>

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include 'sidebar.php';?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                   <?php include 'topnav.php';
                  ?>
                
                        
                      

                </nav>
                 <div class="container-fluid">
                <!-- End of Topbar -->
  <h2 align="center"> course </h2>
  

  <form method="POST" class="form-inline container mt-4 mb-4">
   <div class="row">
    <div class="col-sm">
    <input class="form-control border-end-0 border rounded-pill" name="search" type="text" placeholder="Search by Id , Batch Name " aria-label="Search" style="width:800px" id="example-search-input">
       </div>
    <div class="col-sm">
       <button class="btn btn-outline-secondary bg-white border-bottom-0 border rounded-pill ms-n5" name="submit" value="submit" type="submit">
        <i class="fa fa-search"></i>
     </button>
       <button type="button" align="center" name="add" class="btn btn-info"  data-bs-toggle="modal" data-bs-target="#myModal">ADD</button>
       </div>
    </div>
    </form>
  <!--  display group -->
  
   <form action="" method="post">
      <div class="card-body">
                            <div class="table-responsive">
                            
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
       <tr class="tr" align="center">
       <th> Course Id</th>
       <th> Course Name</th>
       <th> Credit</th>
       <th> Sem </th>
       <th> Batch </th>
        <th> Update</th>
       <th> Delete</th>
    
        </tr>
        <?php
      if(isset($_POST['submit']))
        {
            $keyword=$_POST['search'];
            $keywords=explode(' ',$keyword);
            $query="select * from course where ";
            foreach($keywords as $k)
            {
                $query.="course_name like '%$k%' and ";
            }
            $course = substr_replace($query, "", -4);
           
        }
    else{
         
       
     
        $course="SELECT * FROM course";
    } 
        $course_run=mysqli_query($connection,$course);
        while($row=mysqli_fetch_assoc($course_run))
              {   $id=$row['course_id'];
                  $course=$row['course_name'];
                  $credit=$row['credit'];
                  $sem=$row['sem'];
                  $batchid=$row['batch_id'];
       
        $batch="SELECT batch FROM batch where id='$batchid'";
              
                                        
        $batch_run=mysqli_query($connection,$batch);
        while($rows=mysqli_fetch_assoc($batch_run))
              {   $name=$rows['batch'];
              
              }
                 ?>
        <tr class="tr" align="center"> 
            <td><?php echo $id; ?> </td>
        <td><?php echo $course; ?> </td>
        <td><?php echo $credit; ?> </td>
        <td><?php echo $sem; ?> </td>
             
             
       
        <td><?php echo $name; ?> </td>
         <td><a href="course_insert.php?update=<?php echo $id;?>"style="text-decoration:none; color: white"> <i class="fa fa-edit  " style="font-size:24px;color: #1e60c9;"></i> </a></td>
         
       <td><a href="course_insert.php?delete=<?php echo $id;?>" onclick="return confirm('Are you sure you want to delete this item')" style="text-decoration:none; color: white;"><i class="fas fa-trash-alt"  style="font-size:24px;color: #bb2c2c;"></i> </a></td>
        </tr>
        
       <?php 
              }
         // Delete Group
          
        if(isset($_GET['delete']))
           {
            echo $del=$_GET['delete'];
            $delete="DELETE FROM course WHERE course_id='$del'";
            $delete_run=mysqli_query($connection,$delete);
                
            /*
            $course=mysqli_query($connection,"select sem,name,batch_id from course WHERE course_id='$del'");
            while($row=mysqli_fetch_assoc($course)){
                $batch=mysqli_query($connection,"select batch from batch where id= '".$row['batch_id']."'");
                 while($row=mysqli_fetch_assoc($course))*/
                     
            
// Check if folder exists
/*if (is_dir('..file/'.$existing_folder . '/' . $folder_name)) {
    // Remove directory
    rmdir('..file/'.$existing_folder . '/' . $folder_name);
}*/
         ?>
            <script> location.replace("course_insert.php"); </script>
          <?php  
          }
  
             ?>
                   
          <!--  Add group -->   
    <div class="container mt-5">
        
        <div class="modal" id="myModal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header butt">
                        <h5 class="modal-title">Course Add</h5>
                        <button type="button" required class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <form>
                           <div class="mb-3">
                                <label class="form-label required">Course Id</label>
                                <input type="text" name="id" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label class="form-label required">Course Name</label>
                                <input type="text" name="name" class="form-control">
                            </div>
                           
                             <div class="mb-3">
                                <label class="form-label required">Credit</label>
                                 <input type="text" name="credit" class="form-control">
                 </div>
                          <div class="mb-3">
                                <label class="form-label required">Sem</label>
                                 <input type="text" name="sem" class="form-control">
                 </div>
                          <div class="mb-3">
                                <label class="form-label required">Batch</label><br>
                                    <select name="batch" id="select">
                               
           
            <?php
                                    $id="Select batch,id from batch";
                                    $query_run=mysqli_query($connection,$id);
             while($rows=mysqli_fetch_assoc($query_run))
             {
                 $id=$rows['id'];
                 $batch=$rows['batch'];
                $b=$batch;
                 echo"<option value='".$id."'>".$batch."</option>";
             }
    ?>   
                               
  </select>
                 </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="add" class="btn btn-info" >Submit</button>
                        <button type="submit" name="cancel" class="btn btn-info" >Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    
<?php  
        if(isset($_POST['add']))
        {
            if(!empty($_POST['name'])&&!empty($_POST['credit'])&&!empty($_POST['id'
            ]))
        {
              $id=$_POST['id'];
              $name=$_POST['name'];  
              $credit=$_POST['credit']; 
              $batch=$_POST['batch'];
              $sem=$_POST['sem'];
          $insert="INSERT INTO course(course_id,course_name,credit,batch_id,sem) VALUES('$id','$name','$credit','$batch','$sem')";
            $insert_db=mysqli_query($connection,$insert);
            
        $batch_name="Select batch from batch where id=$batch";
            $query_run=mysqli_query($connection,$batch_name);
             while($rows=mysqli_fetch_assoc($query_run))
             {
                 
                 $name_batch=$rows['batch'];
             
        
       
    if($insert_db)
    {
        
      
        echo "<script>alert('successfully Added');</script>";
      ?>
        <script> location.replace("course_insert.php"); </script>
        <?php
    }
                
            else
            {
                echo mysqli_error($connection);
            }
        }
            }
        }
          ?>
            <!--  Update group -->
       <?php 
   if(isset($_GET['update'])) {
  $update = $_GET['update'];
  echo '
  <script>
    $(document).ready(function() {
      $("#mysModal").modal("show");
    });
  </script>
  ';
    }
                                                   
    ?>
                       
          <!--  Add group -->   
    <div class="container mt-5">
        
        <div class="modal" id="mysModal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header butt">
                        <h5 class="modal-title">Course Add</h5>
                        <button type="button" required class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                    <?php
                            $update=$_GET['update'];
                            $courseupdate="select * from course where course_id= '$update '";
      
        $courserun=mysqli_query($connection,$courseupdate);
        while($rows=mysqli_fetch_assoc($courserun))
              {  
            $id=$rows['course_id'];
                            $name=$rows['course_name'];
                            $credit=$rows['credit'];
              $batch_id=$rows['batch_id'];
              $sem=$rows['sem'];
        
             
             
            ?>
                           <div class="mb-3">
                                <label class="form-label required readonly">Course Id</label>
                                <input type="text" name="id" value="<?php echo $id;?>" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label class="form-label required">Course Name</label>
                                <input type="text" name="names" value="<?php echo $name;?>" class="form-control">
                            </div>
                           
                             <div class="mb-3">
                                <label class="form-label required">Credit</label>
                                 <input type="text" name="credits" value="<?php echo $credit?>" class="form-control">
                 </div>
                          <div class="mb-3">
                                <label class="form-label required">Sem</label>
                                 <input type="text" name="sems" value="<?php echo $sem;?>" class="form-control">
                 </div>
                          <div class="mb-3">
                                <label class="form-label required">Batch</label><br>
                                    <select name="batchs"  value="<?php echo $batch_id;?>"id="select">
                               
           
            <?php
                                    $id="Select batch,id from batch";
                                    $query_run=mysqli_query($connection,$id);
             while($rows=mysqli_fetch_assoc($query_run))
             {
                 $id=$rows['id'];
                 $batch=$rows['batch'];
                $b=$batch;
                 echo"<option value='".$id."'>".$batch."</option>";
             }
        }
    ?>   
                               
  </select>
                 </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="update" class="btn btn-info" >Submit</button>
                        <button type="submit" name="cancel" class="btn btn-info" >Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

   
   
     
                                <?php 
                 if(isset($_POST['update']))
    {
              $cupdate=$_GET['update'];
              $name=$_POST['names'];  
              $credit=$_POST['credits']; 
              $batch=$_POST['batchs'];
              $sem=$_POST['sems'];
       $query_update="UPDATE course SET course_name='$name',credit='$credit',batch_id='$batch',sem='$sem' WHERE course_id= '$cupdate'";
                     echo $query_update;
        $result_update = mysqli_query($connection,$query_update); 
       if($result_update)
       {
                   echo "<script>alert('successfully Updated');</script>";

       
            ?>
            
   <script> location.replace("course_insert.php"); </script>
    <?php
       }
                 }      
    
     
    
       ?>  
        
        
        
        
        
       
    </table>          
    
  
    
      
       
    </div> </form>
</body>
</html>
 </html>
 
                    
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>



    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>

