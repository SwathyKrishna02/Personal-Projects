<?php

include "./header.php";
include "./footer.php";

?>

<?php session_start();?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>   CC Chair</title>
    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.css" rel="stylesheet">
    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
</head>
<body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Sidebar -->
        <?php include 'sidebar.php';?>
        <!-- End of Sidebar -->
        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <!-- Main Content -->
            <div id="content">
                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                   <?php include 'topnav.php';
                  ?>
                </nav>
                 <div class="container-fluid">
                <!-- End of Topbar -->
  <h2 align="center"> View Files </h2>
    
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
       <link href="vendor/fontawesome-free/css/all.css" rel="stylesheet" type="text/css"> <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet"> <!-- Custom styles for this template--> <link href="css/sb-admin-2.css" rel="stylesheet"> 
       
       <br>
<style>
    .batch-text:hover + .Extra-Text 
    {
    display: block;
    }
    .Extra-Text {
    margin-top: auto;
    width: 150px;
    border: 1px solid #000000;
    padding: auto;
    font-size: 12px;
    display: none;
    }
</style><br>
<div class="row">
  
<?php
       if(!isset($_GET['batch'])&& !isset($_GET['group'])&&!isset($_GET['course']))
 {              
$folderPath = '../file';

$folders = scandir($folderPath);

foreach ($folders as $folder) {
    if (is_dir($folderPath . '/' . $folder) && $folder != '.' && $folder != '..') {
        ?>
         <div class="col-xs-6 pr-5">
    <a href="../hod/view_file.php?batch=<?php echo $folder; ?>">   
                        <span id="boot-icon" class="bi bi-folder-fill" style="font-size: 57px; border: 8px hidden; background-color: rgb(242, 242, 242); padding: 25px; border-radius: 17%; color: rgb(241, 200, 88);"></span> 
                        <br><br>
                        <p class="batch-text" style="text-align:center;">
                        <?php
                        echo substr($folder,0,13);
                        
                        ?>
                        </p>   </a>
                        <div class="Extra-Text">
                            <p>
                            <?php echo $folder;?>
                            </p>
                        </div>
                    </div><?php
    }
}
       }
    
    
?>
   
<?php
    
 if(isset($_GET['batch'])&& !isset($_GET['group'])&&!isset($_GET['sem'])&&!isset($_GET['course']))
 {
     $batch=$_GET['batch'];
    
                     
$groupPath = '../file/'.$batch;

if (is_dir($groupPath)) {
    // Proceed with scanning and displaying folders
    $groupfolders = scandir($groupPath);

foreach ($groupfolders as $group) {
    if (is_dir($groupPath . '/' . $group) && $group != '.' && $group != '..') {
        ?>
         <div class="col-xs-6 pr-5">
    <a href="../hod/view_file.php?batch=<?php echo $batch; ?>&group=<?php echo $group?>">   
                        <span id="boot-icon" class="bi bi-folder-fill" style="font-size: 57px; border: 8px hidden; background-color: rgb(242, 242, 242); padding: 25px; border-radius: 17%; color: rgb(241, 200, 88);"></span> 
                        <br><br>
                        <p class="batch-text" style="text-align:center;">
                        <?php
                        echo substr($group,0,13);
                        
                        ?>
                        </p>   </a>
                        <div class="Extra-Text">
                            <p>
                            <?php echo $group;?>
                            </p>
                        </div>
                    </div><?php
    }
}
 }
      else {
    echo 'Directory does not exist.';
}
    }
       
 if(isset($_GET['batch'])&&isset($_GET['group']) &&!isset($_GET['sem'])&&!isset($_GET['course']))
 {
     $batch=$_GET['batch'];
     $group=$_GET['group'];
                     
$semPath = '../file/'.$batch.'/'.$group;

if (is_dir($semPath)) {
    // Proceed with scanning and displaying folders
    $semfolders = scandir($semPath);

foreach ($semfolders as $sem) {
    if (is_dir($semPath . '/' . $sem) && $sem != '.' && $sem != '..') {
        ?>
         <div class="col-xs-6 pr-5">
    <a href="../hod/view_file.php?batch=<?php echo $batch; ?>&group=<?php echo $group; ?>&sem=<?php echo $sem; ?>">   
                        <span id="boot-icon" class="bi bi-folder-fill" style="font-size: 57px; border: 8px hidden; background-color: rgb(242, 242, 242); padding: 25px; border-radius: 17%; color: rgb(241, 200, 88);"></span> 
                        <br><br>
                        <p class="batch-text" style="text-align:center;">
                        <?php
                        echo substr($sem,0,13);
                        
                        ?>
                        </p>   </a>
                        <div class="Extra-Text">
                            <p>
                            <?php echo $sem;?>
                            </p>
                        </div>
                    </div><?php
    }
}
 }
      else {
    echo 'Directory does not exist.';
}
    }
    
    
     if(isset($_GET['batch'])&&isset($_GET['group'])&&isset($_GET['sem'])&&!isset($_GET['course']) )
 {
     $batch=$_GET['batch'];
     $group=$_GET['group'];
     $sem=$_GET['sem'];
                     
$coursePath = '../file/'.$batch.'/'.$group.'/'.$sem;

if (is_dir($coursePath)) {
    // Proceed with scanning and displaying folders
    $coursefolders = scandir($coursePath);

foreach ($coursefolders as $course) {
    if (is_dir($coursePath . '/' . $course) && $course != '.' && $course != '..') {
        ?>
         <div class="col-xs-6 pr-5">
    <a href="../hod/view_file.php?batch=<?php echo $batch; ?>&group=<?php echo $group; ?>&sem=<?php echo $sem; ?>&course=<?php echo $course; ?>">   
                        <span id="boot-icon" class="bi bi-folder-fill" style="font-size: 57px; border: 8px hidden; background-color: rgb(242, 242, 242); padding: 25px; border-radius: 17%; color: rgb(241, 200, 88);"></span> 
                        <br><br>
                        <p class="batch-text" style="text-align:center;">
                        <?php
                        echo substr($course,0,13);
                        
                        ?>
                        </p>   </a>
                        <div class="Extra-Text">
                            <p>
                            <?php echo $course;?>
                            </p>
                        </div>
                    </div><?php
    }
}
 }
      else {
    echo 'Directory does not exist.';
}
    }
    
         if(isset($_GET['batch'])&&isset($_GET['group'])&&isset($_GET['sem']) &&isset($_GET['course'])&&!isset($_GET['fac']))
 {
     $batch=$_GET['batch'];
     $group=$_GET['group'];
     $sem=$_GET['sem'];
     $course=$_GET['course'];
                     
$facPath = '../file/'.$batch.'/'.$group.'/'.$sem.'/'.$course;

if (is_dir($facPath)) {
    // Proceed with scanning and displaying folders
    $facfolders = scandir($facPath);

foreach ($facfolders as $fac) {
    if (is_dir($facPath . '/' . $fac) && $fac != '.' && $fac != '..') {
        ?>
         <div class="col-xs-6 pr-5">
    <a href="../hod/view_file.php?batch=<?php echo $batch; ?>&group=<?php echo $group; ?>&sem=<?php echo $sem; ?>&course=<?php echo $course; ?>&fac=<?php echo $fac; ?>">   
                        <span id="boot-icon" class="bi bi-folder-fill" style="font-size: 57px; border: 8px hidden; background-color: rgb(242, 242, 242); padding: 25px; border-radius: 17%; color: rgb(241, 200, 88);"></span> 
                        <br><br>
                        <p class="batch-text" style="text-align:center;">
                        <?php
                        echo substr($fac,0,13);
                        
                        ?>
                        </p>   </a>
                        <div class="Extra-Text">
                            <p>
                            <?php echo $fac;?>
                            </p>
                        </div>
                    </div><?php
    }
}
 }
      else {
    echo 'Directory does not exist.';
}
    }
            if(isset($_GET['batch'])&& isset($_GET['group'])&& isset($_GET['sem']) && isset($_GET['course'])&& isset($_GET['fac']))
                    {
                          $batch=$_GET['batch'];
                         $group=$_GET['group'];
                         $sem=$_GET['sem'];
                          $course=$_GET['course'];
                          $fac_name=$_GET['fac'];
                $fac = substr( $fac_name, 0, strpos( $fac_name, '_'));
                 
                       $q=mysqli_query($connection,"select * from file where fac_id = '".$fac."' and group_id =(select group_id from group_details where name='".$group."')  and course_id = (select course_id from course where course_name='".$course."' and sem ='".$sem."' )"); 
                       while($file_result=mysqli_fetch_assoc($q))
                       {
                           $of = '../file/'.$batch.'/'.$group.'/'.$sem.'/'.$course.'/'.$fac."/".$file_result['file_name'];
                            ?>
                            <div class="pr-3">
                                        <a href="<?php echo '../file/'.$batch.'/'.$group.'/'.$sem.'/'.$course.'/'.$fac_name."/".$file_result['file_name'];;?>">
                                        <?php
                                       if(preg_match("/\.docx\b/",$file_result['file_name']))
                                       {
                                    ?>

                                            <img src="https://download.logo.wine/logo/Microsoft_Word/Microsoft_Word-Logo.wine.png" width="90">

                                  <?php }
                                        else if(preg_match("/\.pdf\b/",$file_result['file_name']))
                                        {?>

                                        <img class="mt-1 mr-3" src="https://www.freeiconspng.com/thumbs/pdf-icon-png/pdf-word-icon-31.png" width="50">
                                        <?php 
                                        }
                                        else if(preg_match("/\.xlsx\b/",$file_result['file_name']))
                                        {?>

                                        <img class="mt-1" src="https://th.bing.com/th/id/R.5c4ec829490e04d5e33e2dc9d2b3c585?rik=J5TjjeSMKgHZ9A&riu=http%3a%2f%2fclipart-library.com%2fimages_k%2fexcel-icon-transparent%2fexcel-icon-transparent-2.png&ehk=lJ7PEFnVH72iv2al%2fiDjXB%2fVaLtJN%2bM2X6kujzNO7J8%3d&risl=&pid=ImgRaw&r=0" width="100">
                                        <?php 
                                        }
                                        else if(preg_match("/\.pptx\b/",$file_result['file_name']))
                                        {?>

                                        <img class="ml-3" src="https://th.bing.com/th/id/R.b9532431e6988c08319be83cec1c9601?rik=bvgcLQJGr2VGLA&riu=http%3a%2f%2fpluspng.com%2fimg-png%2fpng-powerpoint-microsoft-powerpoint-network-icon-image-483-2000.png&ehk=cMryyGjeMvTeeoGS3BQq3xWX2yFsvbcbxHjQoLGS85M%3d&risl=&pid=ImgRaw&r=0" width="55">
                                        <?php 
                                        }
                                        else 
                                        {?>

                                        <img class="mt-1 mr-2 ml-2" src="https://cdn2.iconfinder.com/data/icons/files-documents-13/128/file_txt_document_extension_files_text-512.png" width="50">
                                        <?php 
                                        }
                           
                                       echo $file_result['file_name'];?>
                                       </a>
                            </div>
                            <?php
                            
                       }
                        
                    }
    
    ?>