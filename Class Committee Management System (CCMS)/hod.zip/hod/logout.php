<!--end all the session -->
<?php
session_start();
$_SESSION['username']=null;
header("Location: login.php");
?>
