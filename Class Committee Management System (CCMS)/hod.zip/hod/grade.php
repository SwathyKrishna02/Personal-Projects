
<html lang="en">
<head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Student portal</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.css" rel="stylesheet">

</head>

<body id="page-top">
    <?php
    
        include '../database.php';

        session_start();
        if(empty($SESSION['roll']) && empty($_SESSION['password']) && $_SESSION['email']=="" )
        {
            header("location:login.php");
        }

    
 
        
    ?>
    <!-- Page Wrapper -->
    <div id="wrapper">
    
    <!-- Sidebar -->
    <?php include 'sidebar.php';?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">
    <!-- Main Content -->
    <div id="content">
    <!-- Topbar -->
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

    <!-- Sidebar Toggle (Topbar) -->
    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
        <i class="fa fa-bars"></i>
    </button>


    <!-- Topbar Navbar -->
    <?php include 'topnav.php'; ?>
    <!-- End of Topbar -->

    <!-- Begin Page Content -->
    <div class="container-fluid">
     <h2 align="center"> Grade Book </h2><br>
<div class="row">

<?php
        if(!isset($_GET['c']) && !isset($_GET['g']) && !isset($_GET['fac_id']) && !isset($_GET['marksheet']))
        {
            $group=mysqli_query($connection,"select * from group_details");
            while($row= mysqli_fetch_assoc($group))
            {
                $group_id=$row['group_id'];
                $group_name=$row['name'];?>

                                <div class="col-xl-3 col-md-6 mb-4">
                                    <div class="card border-left-primary shadow py-2">
                                       <a href=grade.php?g=<?php echo $group_id;?>>
                                        <div class="card-body">
                                            <div class="row no-gutters align-items-center">
                                                <div class="col mr-2">
                                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                      </div>
                                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $group_name?></div>
                                                </div>

                                            </div>
                                        </div>

                                        </a>
                                    </div></div>
                                <?php
            }
        }
    
        else if(isset($_GET['g']) && !isset($_GET['c']) && !isset($_GET['fac_id']) && !isset($_GET['marksheet']))
        {
            $g=$_GET['g'];
            $course=mysqli_query($connection,"SELECT * from course where course_id in (SELECT course_id from grade_finalizationcc where group_id=$g)");
            while($rows= mysqli_fetch_assoc($course))
            {
            $course_id=$rows['course_id'];
            $course_name=$rows['course_name'];
        ?>
            
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow py-2">
                               <a href="grade.php?g=<?php echo $g; ?>&c=<?php echo $course_id;?>">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                              </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $course_name;?></div>
                                        </div>
                                       
                                    </div>
                                </div>
                           
                                </a>
                            </div></div>
                        <?php
                        }
        }
 
 else if(isset($_GET['g']) && isset($_GET['c']) && !isset($_GET['fac_id']) && !isset($_GET['marksheet']))
{
    $group_id=$_GET['g'];
     $course_id=$_GET['c'];
    $row_gradesheet = mysqli_query($connection,"select * from grade_finalizationcc where group_id =$group_id and course_id='$course_id'");
     
    while($result_gradesheet = mysqli_fetch_assoc($row_gradesheet))
    {
        $row_course = mysqli_query($connection,"select * from course where course_id = '".$result_gradesheet['course_id']."'");
        $result_course = mysqli_fetch_assoc($row_course);
        $row_faculty=mysqli_query($connection,"select * from faculty where fac_id = '".$result_gradesheet['fac_id']."'");
        $result_faculty = mysqli_fetch_assoc($row_faculty); 
        ?>
        <div class="list-group">
          <a href="grade.php?g=<?php echo $group_id; ?>&c=<?php echo $result_course['course_id'];?>&course_name=<?php echo $result_course['course_name'];?>&fac_id=<?php echo $result_faculty['fac_id'];?>&marksheet=<?php echo $result_gradesheet['tentative_grade_report'];?>"  class="list-group-item list-group-item-action">
            <div class="d-flex w-100 justify-content-between">
              <h5 class="mb-1"><?php echo $result_course['course_id']." ".$result_course['course_name'];?></h5>
            </div>
            <small class="text-muted">published by: <?php echo $result_faculty['fac_name'];?></small>
          </a>
        </div>
        <?php  
    }
}
else if(isset($_GET['g']) && isset($_GET['c']) && isset($_GET['fac_id']) && isset($_GET['marksheet']) )
{
    $row_f=mysqli_query($connection,"select * from faculty where fac_id ='".$_GET['fac_id']."'");   
    $result_f = mysqli_fetch_assoc($row_f);
    $GLOBALS['fac']=$result_f['fac_name'];
    $row = mysqli_query($connection,"select * from grade_finalizationcc where fac_id ='".$_GET['fac_id']."' and course_id = '".$_GET['c']."' and group_id = ".$_GET['g']);
    $result = mysqli_fetch_assoc($row);
    ?>
    <div class="card shadow mb-4">
            <div class="card-body" style="
    width: 1000;">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                       <tbody>
                        <?php
                        require_once "Classes/PHPExcel.php";
 
    $batch_r=mysqli_query($connection,"select batch from batch where id=(select batch_id from group_details where group_id=".$_GET['g'].")");   
    $row_r=mysqli_fetch_assoc($batch_r);

        $group=mysqli_query($connection,"select name from group_details where group_id=".$_GET['g']);   
    $rows=mysqli_fetch_assoc($group);
    
      $sem=mysqli_query($connection,"select * from course where course_id='".$_GET['c']."'");   
    $semrows=mysqli_fetch_assoc($sem);
    

    
    $path="../file/".$row_r['batch']."/".$rows['name']."/".$semrows['sem']."/".$semrows['course_name']."/".$_GET['fac_id']."_".$GLOBALS['fac']."/".$_GET['marksheet'];
    
                        $reader= PHPExcel_IOFactory::createReaderForFile($path);
                        $excel_Obj = $reader->load($path);
                        $count = 0; //total count of students
                        $avg=0;//store avg 
                        $ab_count=0;//total number of ab
                        $worksheet=$excel_Obj->getSheet('0');
                        $lastRow = $worksheet->getHighestRow();

                        $colomncount = $worksheet->getHighestDataColumn();

                        $colomncount_number=PHPExcel_Cell::columnIndexFromString($colomncount);

                            for($row=0;$row<=$lastRow;$row++)
                            {
                                echo "<tr>";
                                for($col=0;$col<=$colomncount_number;$col++)
                                {


                                    if($worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue()!="")
                                    {
                                        echo "<td>";
                                        echo $worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();
                                        echo "</td>";
                                        //finding outoff
                                        if($col==2&&$row==1)
                                        {
                                            $outoff = substr($worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue(),5);
                                        }
                                        
                                        if($col==2&&$row!=1)
                                        {
                                            $count++;
                                            echo "<td>";
                                            if(!is_numeric($worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue()))
                                            {
                                                $ab_count++;
                                                echo "Absent";
                                            }
                                            else if(($worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue()/$outoff)*100>=$result['o'])
                                            {
                                                $avg+=$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();
                                                echo "O";
                                            }
                                            else if(($worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue()/$outoff)*100>=$result['ap'])
                                            {                                                                                                $avg+=$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();
                                                echo "A+";
                                            }
                                            else if(($worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue()/$outoff)*100>=$result['a'])
                                            {
                                                $avg+=$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();
                                                echo "A";
                                            }
                                            else if(($worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue()/$outoff)*100>=$result['bp'])
                                            {
                                                echo "B+";
                                                $avg+=$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();

                                            }
                                            else if(($worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue()/$outoff)*100>=$result['b'])
                                            {
                                                echo "B";
                                                $avg+=$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();

                                            }
                                            else if(($worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue()/$outoff)*100>=$result['c'])
                                            {
                                                echo "C";
                                                $avg+=$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();

                                            }
                                            else if(($worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue()/$outoff)*100>=$result['d'])
                                            {
                                                echo "D";
                                                $avg+=$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();

                                            }
                                            else if(($worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue()/$outoff)*100<=$result['f'])
                                            {
                                                echo "F";
                                                $avg+=$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();

                                            }
                                            echo "</td>";
                                        }
                                    }

                                    if($row==1 && $col ==2)
                                    {
                                        echo "<td>Grade</td>";
                                    }

                                }

                                echo "</tr>";
                            }	
                        ?>
                        </tbody>
                </table>
            </div>
        </div>
    </div>
    
    
    
    
    
  </div>
    
    
    <!-- Content Row -->
    <div class="row pt-2">
                       
                        <!-- Card 1 -->
                        <div class="col-xl-3 col-md-6 mb-4">
                           
                           <a href="" style="text-decoration:none;">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Total Students</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php echo "<small><i>".$count."</i></small>";?>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-users fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </a>
                        </div>
                        
                        <!-- Card 2 -->
                        <div class="col-xl-3 col-md-6 mb-4">
                           
                           <a href="" style="text-decoration:none;">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Class Average</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php  echo "<small><i>".strval(($avg/$count))."</i></small>";?>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-balance-scale fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </a>
                        </div>
                        
                         <!-- Card 3 -->
                        <div class="col-xl-3 col-md-6 mb-4">
                           
                           <a href="" style="text-decoration:none;">
                            <div class="card border-left-danger shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                                absentees</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                            <?php  echo "<small><i>".strval($ab_count)."</i></small>";?>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-times fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </a>
                        </div>
        </div>
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    <div class="card shadow mb-4">    
    <div class="card-body">
    <div class="table-responsive">
    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
      <tbody>
         <?php 
          echo "<tr>";
          echo "<td>Grade</td><td>Range</td>";
          echo "</tr>";
    
          echo "<tr>";
          echo "<td>O</td><td>100-".$result['o']."</td>";
          echo "</tr>";
    
          echo "<tr>";
          echo "<td>A+</td><td>".strval($result['o']+1)." - ".$result['ap']."</td>";
          echo "</tr>";
    
          echo "<tr>";
          echo "<td>A</td><td>".strval($result['ap']+1)." - ".$result['a']."</td>";
          echo "</tr>";
    
          echo "<tr>";
          echo "<td>B+</td><td>".strval($result['a']+1)." - ".$result['bp']."</td>";
          echo "</tr>";
    
          echo "<tr>";
          echo "<td>B</td><td>".strval($result['bp']+1)." - ".$result['b']."</td>";
          echo "</tr>";
          
          echo "<tr>";
          echo "<td>C</td><td>".strval($result['b']+1)." - ".$result['c']."</td>";
          echo "</tr>";
    
          echo "<tr>";
          echo "<td>D</td><td>".strval($result['c']+1)." - ".$result['d']."</td>";
          echo "</tr>";
    
          echo "<tr>";
          echo "<td>F</td><td>".strval($result['f']+1)." - 0"."</td>";
          echo "</tr>";
          ?>
          
      </tbody>
    </table>
    </div>
    </div>
        </div>
    
    

<?php
}
        else
        {echo "dc";}
?>














    </div>
                           
    <!-- End of Page Wrapper -->
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

   

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>