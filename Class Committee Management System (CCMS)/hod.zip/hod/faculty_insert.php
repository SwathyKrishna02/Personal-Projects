<style>
.btn[name="add"]
    {
        background-color: #1e60c9;
    }
.btn[name="view"]
    {
        background-color: #1e60c9;
    }
.btn[name="cancel"]
    {
        background-color: #1e60c9;
    }
        .btn[name="update"] {
background-color: #1e60c9;
}
</style><?php

include "./header.php";
include "./footer.php";

// css
?>
<?php session_start();?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Faculty</title>

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include 'sidebar.php';?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                   <?php include 'topnav.php';
                  ?>
                
                        
                      

                </nav>
                 <div class="container-fluid">
                <!-- End of Topbar -->
  <h2 align="center"> Faculty </h2>
  

  <form method="POST" class="form-inline container mt-4 mb-4">
   <div class="row">
    <div class="col-sm">
    <input class="form-control border-end-0 border rounded-pill" name="search" type="text" placeholder="Search by Group Id , Batch Name " aria-label="Search" style="width:800px" id="example-search-input">
       </div>
    <div class="col-sm">
       <button class="btn btn-outline-secondary bg-white border-bottom-0 border rounded-pill ms-n5" name="submit" value="submit" type="submit">
        <i class="fa fa-search"></i>
     </button>
       <button type="button" align="center" name="add" class="btn btn-info"  data-bs-toggle="modal" data-bs-target="#myModal">ADD</button>
       </div>
    </div>
    </form>
  <!--  display group -->
  
   <form action="" method="post">
  <div class="card-body">
                            <div class="table-responsive">
                            
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
       <tr class="tr">
       <th> Fac Image</th>
       <th> Fac Id</th>
       <th> Fac Name</th>
       <th> Dept</th>
        <th> Email</th>
        <th> Update</th>
       <th> Delete</th>
    
      
        
                                        </tr>
                                    </thead>
                                    <tbody>
        <?php
      if(isset($_POST['submit']))
        {
            $keyword=$_POST['search'];
            $keywords=explode(' ',$keyword);
            $query="select * from faculty where ";
            foreach($keywords as $k)
            {
                $query.="fac_id like '%$k%' or fac_name like '%$k%' and ";
            }
            $batch = substr_replace($query, "", -4);
           
        }
    else{
         ?>
                                            <?php
     
        $batch="SELECT * FROM faculty";
    } 
        $batch_run=mysqli_query($connection,$batch);
        while($row=mysqli_fetch_assoc($batch_run))
              {      
                  $fac_id=$row['fac_id'];
                  $fac_name=$row['fac_name'];
                  $email=$row['email'];
             
        ?>
        <tr> 
        <td>
       <img style="width:50px;border-radius:50%;" src="
                                           <?php 
                                        
                                             $path='../images/fac_prof/'.$fac_id.'.png';
                                             
                                             if(file_exists($path)){
                                            echo $path;
                                            }
                                             else echo "../images/fac_prof/default.png";
                                            ?>
                                                        
                                                        "> 
                                                        </td>
        <td><?php echo $fac_id; ?> </td>
        <td><?php echo $fac_name; ?> </td>
        <td>  <?php echo "CSA"; ?></td>
        <td><?php echo $email; ?> </td>
         <td> <a href="faculty_insert.php?update=<?php echo $fac_id;?>"style="text-decoration:none; color: white"> <i class="fa fa-edit  " style="font-size:24px;color: #1e60c9;"></i> </a></td>
         
       <td>  <a href="faculty_insert.php?delete=<?php echo $fac_id;?>" onclick="return confirm('Are you sure you want to delete this item')" style="text-decoration:none; color: white;"> <i class="fas fa-trash-alt"  style="font-size:24px;color: #bb2c2c;"></i></a></td>
        </tr>
        
       <?php 
         }
         // Delete Group
          
        if(isset($_GET['delete']))
           {
            $del=$_GET['delete'];
            $delete="DELETE FROM faculty WHERE fac_id='$del'";
            $delete_run=mysqli_query($connection,$delete);
         ?>
            <script> location.replace("faculty_insert.php"); </script>
          <?php  
          }
  
             ?>
                   
          <!--  Add group -->   
    <div class="container mt-5">
        
        <div class="modal" id="myModal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header butt">
                        <h5 class="modal-title">Faculty Add</h5>
                        <button type="button" required class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <form method="POST">
                           
                            <div class="mb-3">
                                <label class="form-label required">Faculty Id</label>
                                <input type="text" name="id" class="form-control">
                            </div>
                           
                             <div class="mb-3">
                                <label class="form-label required">Faculty Name</label>
                                 <input type="text" name="name" class="form-control">
                 </div>
                          <div class="mb-3">
                                <label class="form-label required">Department</label>
                                 <input type="text" name="group" readonly value="CSA" class="form-control">
                 </div>
                          
                             <div class="mb-3">
                                <label class="form-label required">Email</label>
                                 <input type="text" name="email" class="form-control">
                 </div>
                           
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="add" class="btn btn-info" >Submit</button>
                        <button type="submit" name="cancel" class="btn btn-info" >Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    
<?php  
        if(isset($_POST['add']))
        {
            if(!empty($_POST['id'])&&!empty($_POST['name']))
        {
             
              $id=$_POST['id'];  
              $name=$_POST['name']; 
            $email=$_POST['email'];
          
             $insert="INSERT INTO faculty(fac_id,fac_name,dept,email) VALUES('$id','$name','CSA','$email')";
            
            $insert_db=mysqli_query($connection,$insert);
            
        
        
       
    if($insert_db)
    {
        
        echo "<script>alert('successfully Added');</script>";
      ?>
        <script> location.replace("faculty_insert.php"); </script>
        <?php
    }
        }
        }
          
          


  if(isset($_GET['update'])) {
  
  echo '
  <script>
    $(document).ready(function() {
      $("#mysModal").modal("show");
    });
  </script>
  ';
    }         
 
    ?>
   
   
       
    <div class="container mt-5">
        
        <div class="modal" id="mysModal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header butt">
                        <h5 class="modal-title">Faculty Edit</h5>
                        <button type="button" required class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body"><?php
                         $update=$_GET['update'];
                            $facupdate="select * from faculty where fac_id= '$update '";
      
        $grouprun=mysqli_query($connection,$facupdate);
        while($rows=mysqli_fetch_assoc($grouprun))
              {  
                          $id=$rows['fac_id'];
                            $name=$rows['fac_name'];
                   $email=$rows['email'];
                            
              
        ?>
                           
                            <div class="mb-3">
                                <label class="form-label required">Faculty Id</label>
                                <input readonly type="text" name="id" value="<?php echo $id;?>"class="form-control">
                            </div>
                           
                             <div class="mb-3">
                                <label class="form-label required">Faculty Name</label>
                                 <input type="text" name="names" value="<?php echo $name;?>"class="form-control">
                 </div>
                          <div class="mb-3">
                                <label class="form-label required">Department</label>
                                 <input type="text" name="groups" readonly value="CSA" class="form-control">
                 </div>
                               <div class="mb-3">
                                <label class="form-label required">Email</label>
                                 <input type="text" name="emails" value="<?php echo $email; ?>" class="form-control">

                 </div>
                          
                          
                           
                   
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="update" class="btn btn-info" >Submit</button>
                        <button type="submit" name="cancel" class="btn btn-info" >Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
         
        <?php
        if(isset($_POST['update']))
    {
          
       $gupdate=$_GET['update'];
        $emails=$_POST['emails'];
         $names=$_POST['names'];
    
       
         $query_update="UPDATE faculty SET fac_name='$names',email='$emails' WHERE fac_id = '$gupdate'";
             
        $result_update = mysqli_query($connection,$query_update);
            if(!$result_update)
            {
                mysqli_error($connection);
            }
            ?>
   <script> location.replace("faculty_insert.php"); </script>
    <?php
          
        
    }

}
          
 
    ?>
        
       
    </table>          
    
<br><br>
     <div align="center">
     
    
      
       
    </div> </form>

            
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>



    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>

