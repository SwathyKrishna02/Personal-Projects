<style>
.btn[name="add"]
    {
        background-color: #1e60c9;
    }
.btn[name="view"]
    {
        background-color: #1e60c9;
    }
.btn[name="cancel"]
    {
        background-color: #1e60c9;
    }
        .btn[name="update"] {
background-color: #1e60c9;
}
     #select{
 width:460px; 
        height: 40px;
}
</style><?php

include "./header.php";
include "./footer.php";

// css
?>
<?php session_start();?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>   CC Chair</title>

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include 'sidebar.php';?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                   <?php include 'topnav.php';
                  ?>
                
                        
                      

                </nav>
                 <div class="container-fluid">
                 
                <!-- End of Topbar -->
  <h2 align="center"> Group</h2>
  

                <!-- End of Topbar -->
  <h2 align="center"> </h2>
  <form method="POST" class="form-inline container mt-4 mb-4">
   <div class="row">
    <div class="col-sm">
    <input class="form-control border-end-0 border rounded-pill" name="search" type="text" placeholder="Search by Group Id ,Group Name " aria-label="Search" style="width:800px" id="example-search-input">
       </div>
    <div class="col-sm">
       <button class="btn btn-outline-secondary bg-white border-bottom-0 border rounded-pill ms-n5" name="submit" value="submit" type="submit">
        <i class="fa fa-search"></i>
     </button>
       </div>
    </div>
    </form>
  <!--  display group -->
  
   <form action="" method="post">
        <div class="card-body">
                            <div class="table-responsive">
                            
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
       <tr class="tr" align="center">
       <th> Group Name</th>
        <th> Batch </th>
         <th> Year</th>
          <th> Update</th>
       <th> Delete</th>
        <th> View</th></tr>
                                    </thead>
        
        <?php
      if(isset($_POST['submit']))
        {
            $keyword=$_POST['search'];
            $keywords=explode(' ',$keyword);
            $query="select * from group_details ";
            foreach($keywords as $k)
            {
                $query.="group_name like '%$k%'  or group_id like '%$k%'  and ";
            }
            $group= substr_replace($query, "", -4);
           
        }
    else{
         
       
     
        $group="SELECT * FROM group_details  order by year desc";
    } 
        $group_run=mysqli_query($connection,$group);
             if (!$group_run) {
    die("Query execution failed: " . mysqli_error($connection));
}                       
        while($row=mysqli_fetch_assoc($group_run))
              {      
                  $group_id=$row['group_id'];
            $group=$row['name'];
                  $batch_id=$row['batch_id'];
            
                  $year=$row['year']; 
             
        $batch="SELECT batch FROM batch where id='$batch_id'";
    
        $batch_run=mysqli_query($connection,$batch);
        while($rows=mysqli_fetch_assoc($batch_run))
              {      
                  $batch=$rows['batch'];
        }
        ?>
        <tr class="tr" align="center">
         <td><?php echo $group; ?> </td>
        <td><?php echo $batch; ?> </td>
         <td><?php echo $year; ?> </td>
         <td> <a href="group_insert.php?update=<?php echo $group_id;?>"style="text-decoration:none; color: white">  <i class="fa fa-edit  " style="font-size:24px;color: #1e60c9;"></i>  </a></td>
         
         
            <td>  <a href="group_insert.php?delete=<?php echo $group_id;?>" onclick="return confirm('Are you sure you want to delete this item')" style="text-decoration:none; color: white;"><i class="fas fa-trash-alt"  style="font-size:24px;color: #bb2c2c;"></i></a></td>
        <td> <button type="button" align="center" name="view" class="btn btn-info"><a href="group_view.php?view=<?php echo $group_id;?>"style="text-decoration:none; color: white"> View</a></button></td>
        </tr>
        
       <?php 
         }
         // Delete Group
          
        if(isset($_GET['delete']))
           {
            $del=$_GET['delete'];
            $delete="DELETE FROM group_details WHERE group_id='$del'";
            $delete_run=mysqli_query($connection,$delete);
         ?>
            <script> location.replace("group_insert.php"); </script>
          <?php  
          }
  
             ?>
                   
          <!--  Add group -->   
    <div class="container mt-5">
        
        <div class="modal" id="myModal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header butt">
                        <h5 class="modal-title">Group Add</h5>
                        <button type="button" required class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <form>
                           
                           <div class="mb-3">
                                <label class="form-label required">Group Name</label>
                                 <input type="text" name="groups" class="form-control">
                 </div> 
                           
                             <div class="mb-3">
                                <label class="form-label required">Batch Name</label>
                                 <select name="batchs" id="select">
                               
           
            <?php
                                    $id="Select batch,id from batch";
                                    $query_run=mysqli_query($connection,$id);
             while($rows=mysqli_fetch_assoc($query_run))
             {
                 $batch=$rows['batch'];
                 $batch_id=$rows['id'];
                 echo"<option value='".$batch_id."'>".$batch."</option>";
             }
    ?>   
                               
  </select>
                 </div>
                         <div class="mb-3">
                                <label class="form-label required">Year</label>
                                 <input type="text" name="years" class="form-control">
                 </div>
                          
                           
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="add" class="btn btn-info" >Submit</button>
                        <button type="submit" name="cancel" class="btn btn-info" >Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
<?php  
          if(isset($_POST['add'])) {
    if(!empty($_POST['batchs']) && !empty($_POST['groups']) && !empty($_POST['years'])) {
        $batch = $_POST['batchs'];  
        $group_name=$_POST['groups'];
        $yr = $_POST['years'];
      
       $g="";
        $group="SELECT * FROM group_details where batch_id='$batch' and name='$group_name' and year='$yr'";
    
        $group_run=mysqli_query($connection,$group);
        while($row=mysqli_fetch_assoc($group_run))
              {      
                  $g=$row['group_id'];
         
        }
            if($g!='')
            {
                echo "<script>alert('Group already exists');</script>";
            }
        
            else
            {
          
             $insert="INSERT INTO group_details(name,batch_id,year) VALUES('$group_name','$batch','$yr')";
            
            $insert_db=mysqli_query($connection,$insert);
            
      
        
       
    if($insert_db)
    {
                    
$_SESSION['g']  = $_POST['groups'];
$insertt="select batch from batch where id= $batch";            
 $insert_dbb=mysqli_query($connection,$insertt);
             while($rows=mysqli_fetch_assoc($insert_dbb))
             {
$_SESSION['b'] = $rows['batch'];
             
$batch_name=$_SESSION['b'];
                      
$sem="select sem from batch where batch= '$batch_name'";  
                
 $sem_db=mysqli_query($connection,$sem);
             while($row=mysqli_fetch_assoc($sem_db))
             {
                 $sems = $row['sem'];
                 for($i=1;$i<=$sems;$i++)
                 {
                    $course="select course_name from course where batch_id=$batch && sem=$i";            
 $course_db=mysqli_query($connection,$course);
                 
             while($rowss=mysqli_fetch_assoc($course_db))
             {
$name = $rowss['course_name'];
                 

                 

// Check if folder already exists
if (!is_dir('../file/'.$_SESSION['b'].'/'.$_SESSION['g'].'/'.$i.'/'.$name)) {
    // Create new directory
    mkdir('../file/'.$_SESSION['b'].'/'.$_SESSION['g'].'/'.$i.'/'.$name, 0777, true);


             }
        else
        {
            echo "<script>alert('Folder already exists');</script>";
        }
             }
                 }
        }
        
        
      
             
    ?>
                 <script> location.replace("group_insert.php"); </script>    
<?php
             }
             }
    }
    }
       
          }
        
    
          
          
          
           if(isset($_GET['update'])) {
  $update = $_GET['update'];
  echo '
  <script>
    $(document).ready(function() {
      $("#mysModal").modal("show");
    });
  </script>
  ';
    }
                                                   
    ?>
                                <!--  Add group -->   
    <div class="container mt-5">
        
        <div class="modal" id="mysModal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header butt">
                        <h5 class="modal-title">Group Edit</h5>
                        <button type="button" required class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                       <?php
                            $update=$_GET['update'];
                            $groupupdate="select * from group_details where group_id= '$update '";
      
        $grouprun=mysqli_query($connection,$groupupdate);
        while($rows=mysqli_fetch_assoc($grouprun))
              {  
            $id=$rows['group_id'];
                            $name=$rows['name'];
                            
              $batch_id=$rows['batch_id'];
              $year=$rows['year'];
        
             
             
            ?>
                        
                           
                           <div class="mb-3">
                                <label class="form-label required">Group Name</label>
                                 <input type="text" name="groups" value="<?php echo $name;?>"class="form-control">
                 </div> 
                           
                             <div class="mb-3">
                                <label class="form-label required">Batch Name</label>
                                 <select name="batchs" id="select">
                               
           
            <?php
                                    $id="Select batch,id from batch";
                                    $query_run=mysqli_query($connection,$id);
             while($rows=mysqli_fetch_assoc($query_run))
             {
                 $batch=$rows['batch'];
                 $batch_id=$rows['id'];
                 echo"<option value='".$batch_id."'>".$batch."</option>";
             }
    ?>   
                               
  </select>
                 </div>
                         <div class="mb-3">
                                <label class="form-label required">Year</label>
                                 <input type="text" name="years" value="<?php echo $year;?>"class="form-control">
                 </div>
                          
                           
                     
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="update" class="btn btn-info" >Submit</button>
                        <button type="submit" name="cancel" class="btn btn-info" >Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
                       
    if(isset($_POST['update']))
    {
        
       $gupdate=$_GET['update'];
        $group=$_POST['groups'];
         $name=$_POST['batchs'];
       $year=$_POST['years'];
       

        $query_update="UPDATE group_details SET name='$group',batch_id='$name' ,year='$year' WHERE group_id = '$gupdate'";
       
        $result_update = mysqli_query($connection,$query_update);
        if(!$result_update)
            
        {
            mysqli_error($connection);
        }
            ?>
   <script> location.replace("group_insert.php"); </script>
    <?php
          
        
    }

}
          
 
    ?>
        
       
    </table>          
    
<br><br>
     <div align="center">
      <button type="button" align="center" name="add" class="btn btn-info"  data-bs-toggle="modal" data-bs-target="#myModal">ADD</button>&emsp;
    
      
       
                                </div> </div></div></form></div></div></div></div></body></html>
